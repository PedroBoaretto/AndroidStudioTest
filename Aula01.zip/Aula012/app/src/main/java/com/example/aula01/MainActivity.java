package com.example.aula01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView txtHello;
    EditText editNome;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtHello = (TextView) findViewById(R.id.textHello);
        editNome = (EditText) findViewById(R.id.editNome);

    }

    public void btnAplicarClick(View view){
        String nome = editNome.getText().toString();
        txtHello.setText("Ola, " + nome);
        
    }

}